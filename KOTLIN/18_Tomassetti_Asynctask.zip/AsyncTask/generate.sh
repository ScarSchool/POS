#!/bin/bash
cd ./springbootjparest
sh build.sh
