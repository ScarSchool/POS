package com.scarc.springbootjparest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootjparestApplicationTests {

    @Test
    void contextLoads() {
    }

}
