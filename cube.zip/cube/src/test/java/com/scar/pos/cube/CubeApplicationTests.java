package com.scar.pos.cube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CubeApplicationTests {

	@Test
	void contextLoads() {
	}
}
