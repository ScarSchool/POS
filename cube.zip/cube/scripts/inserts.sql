INSERT INTO Cubes(
    sides,
    material,
    corners,
    edges
) VALUES (2, 'Eisen', 4, 2);
INSERT INTO Cubes(
    sides,
    material,
    corners,
    edges
) VALUES (4, 'Metall', 3, 69);
INSERT INTO Cubes(
    sides,
    material,
    corners,
    edges
) VALUES (3, 'Holz', 54, 1);
COMMIT;