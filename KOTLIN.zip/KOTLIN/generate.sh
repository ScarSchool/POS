#!/bin/bash

mvn package
