#!/bin/bash
echo "Opening WebBrowser"
firefox http://localhost:8080/static/index.html

echo "Starting emulator"
~/Android/Sdk/tools/emulator -avd Pixel_2_API_28