pluginManagement {
    repositories {
        google()
        jcenter()
        gradlePluginPortal()
        mavenCentral()
    }
    
}
rootProject.name = "18_Tomassetti_AsyncTasks"


include(":androidApp")
include(":shared")

