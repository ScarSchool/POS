package me.scarc.shared

expect class Platform() {
    val platform: String
}