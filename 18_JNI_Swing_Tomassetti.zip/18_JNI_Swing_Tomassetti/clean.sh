# remove java bin folder
rm -r -f ./bin

# remove native libs
rm -r -f ./lib/*.so
