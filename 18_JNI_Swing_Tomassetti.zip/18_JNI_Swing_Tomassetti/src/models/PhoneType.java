package models;
public enum PhoneType {
	ANDROID, IPHONE, NOKIA
}
