package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.TimeSlot;

import java.util.List;

public interface TimeSlotService {
    List<TimeSlot> getAllTimeSlots();
    TimeSlot getOneTimeSlot(int id);
    TimeSlot createTimeSlot(TimeSlot TimeSlot);
    boolean deleteTimeSlot(int id);
}
