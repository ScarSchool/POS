package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Participation;

import java.util.List;

public interface ParticipationService {
    List<Participation> getAllParticipations();
    Participation getOneParticipation(int id);
    Participation createParticipation(Participation Participation);
    boolean deleteParticipation(int id);
}
