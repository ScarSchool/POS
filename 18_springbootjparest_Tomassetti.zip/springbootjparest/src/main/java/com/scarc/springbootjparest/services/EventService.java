package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Event;

import java.util.List;

public interface EventService {
    List<Event> getAllEvents();
    Event getOneEvent(int id);
    Event createEvent(Event Event);
    boolean deleteEvent(int id);
}
