package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Pupil;

import java.util.List;

public interface PupilService {
    List<Pupil> getAllPupils();
    Pupil getOnePupil(int id);
    Pupil createPupil(Pupil Pupil);
    boolean deletePupil(int id);
}
