package com.scarc.springbootjparest.models;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import java.util.List;

@Data
@Entity
public class Pupil {


  @ManyToMany
  @JoinTable(
          name = "joins",
          joinColumns = @JoinColumn(name = "pupil_id"),
          inverseJoinColumns = @JoinColumn(name = "timeslot_id"))
  private List<TimeSlot> joins;

}
