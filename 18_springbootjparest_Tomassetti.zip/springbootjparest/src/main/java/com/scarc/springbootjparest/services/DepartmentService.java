package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Department;

import java.util.List;

public interface DepartmentService {
    List<Department> getAllDepartments();
    Department getOneDepartment(int id);
    Department createDepartment(Department Department);
    boolean deleteDepartment(int id);
}
