package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Admin;

import java.util.List;

public interface AdminService {
    List<Admin> getAllAdmins();
    Admin getOneAdmin(int id);
    Admin createAdmin(Admin admin);
    boolean deleteAdmin(int id);
}
