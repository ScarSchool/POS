package com.scarc.springbootjparest.services;

import com.scarc.springbootjparest.models.Responsible;

import java.util.List;

public interface ResponsibleService {
    List<Responsible> getAllResponsibles();
    Responsible getOneResponsible(int id);
    Responsible createResponsible(Responsible Responsible);
    boolean deleteResponsible(int id);
}
